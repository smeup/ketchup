const dataStaff = {
    columns: [],
    rows: [
        {
            children: [
                {
                    children: [
                        {
                            children: [
                                {
                                    children: [
                                        {
                                            children: [],
                                            disabled: false,
                                            expandable: false,
                                            icon: 'favorite',
                                            isExpanded: false,
                                            obj: {
                                                k: 'LOCEXD',
                                                p: 'B£AMO',
                                                t: 'TA',
                                            },
                                            options: true,
                                            style: {},
                                            isStaff: true,
                                            value: 'Staff 1',
                                            visible: true,
                                        },
                                        {
                                            children: [],
                                            disabled: false,
                                            expandable: false,
                                            icon: 'favorite',
                                            isExpanded: false,
                                            obj: {
                                                k: 'LOCEXD',
                                                p: 'B£AMO',
                                                t: 'TA',
                                            },
                                            options: true,
                                            style: {},
                                            isStaff: true,
                                            value: 'Staff 2',
                                            visible: true,
                                        },
                                    ],
                                    disabled: false,
                                    expandable: false,
                                    icon: 'favorite',
                                    id: 'LOCEXD',
                                    isExpanded: false,
                                    obj: {
                                        k: 'LOCEXD',
                                        p: 'B£AMO',
                                        t: 'TA',
                                    },
                                    options: true,
                                    style: {},
                                    value: 'Scheda oggetto',
                                    visible: true,
                                },
                            ],
                            disabled: false,
                            expandable: true,
                            icon: 'table-large',
                            id: 'FOS',
                            isExpanded: true,
                            obj: {
                                k: 'FOS',
                                p: 'BRE',
                                t: 'TA',
                            },
                            options: true,
                            style: {},
                            value: 'FOR Debiti operaz. societ.',
                            visible: true,
                        },
                        {
                            children: [
                                {
                                    children: [
                                        {
                                            children: [],
                                            disabled: false,
                                            expandable: false,
                                            icon: 'favorite',
                                            isExpanded: false,
                                            obj: {
                                                k: 'LOCEXD',
                                                p: 'B£AMO',
                                                t: 'TA',
                                            },
                                            options: true,
                                            style: {},
                                            isStaff: true,
                                            value: 'Staff 1',
                                            visible: true,
                                        },
                                        {
                                            children: [],
                                            disabled: false,
                                            expandable: false,
                                            icon: 'favorite',
                                            isExpanded: false,
                                            obj: {
                                                k: 'LOCEXD',
                                                p: 'B£AMO',
                                                t: 'TA',
                                            },
                                            options: true,
                                            style: {},
                                            isStaff: true,
                                            value: 'Staff 2',
                                            visible: true,
                                        },
                                    ],
                                    disabled: false,
                                    expandable: false,
                                    icon: 'favorite',
                                    isExpanded: false,
                                    obj: {
                                        k: 'LOCEXD',
                                        p: 'B£AMO',
                                        t: 'TA',
                                    },
                                    options: true,
                                    style: {},
                                    value: 'Scheda oggetto',
                                    visible: true,
                                },
                                {
                                    children: [],
                                    disabled: false,
                                    expandable: false,
                                    icon: 'favorite',
                                    id: 'LOCTML',
                                    isExpanded: false,
                                    obj: {
                                        k: 'LOCTML',
                                        p: 'B£AMO',
                                        t: 'TA',
                                    },
                                    options: true,
                                    style: {},
                                    value: 'Timeline',
                                    visible: true,
                                },
                                {
                                    children: [],
                                    disabled: false,
                                    expandable: false,
                                    icon: 'favorite',
                                    isExpanded: false,
                                    obj: {
                                        k: 'LOCEXD',
                                        p: 'B£AMO',
                                        t: 'TA',
                                    },
                                    options: true,
                                    style: {},
                                    isStaff: true,
                                    value: 'Staff 1',
                                    visible: true,
                                },
                                {
                                    children: [],
                                    disabled: false,
                                    expandable: false,
                                    icon: 'favorite',
                                    isExpanded: false,
                                    obj: {
                                        k: 'LOCEXD',
                                        p: 'B£AMO',
                                        t: 'TA',
                                    },
                                    options: true,
                                    style: {},
                                    isStaff: true,
                                    value: 'Staff 2',
                                    visible: true,
                                },
                                {
                                    children: [],
                                    disabled: false,
                                    expandable: false,
                                    icon: 'favorite',
                                    isExpanded: false,
                                    obj: {
                                        k: 'LOCEXD',
                                        p: 'B£AMO',
                                        t: 'TA',
                                    },
                                    options: true,
                                    style: {},
                                    isStaff: true,
                                    value: 'Staff 3',
                                    visible: true,
                                },
                            ],
                            disabled: false,
                            expandable: true,
                            icon: 'table-large',
                            id: 'FOS',
                            isExpanded: true,
                            obj: {
                                k: 'FOS',
                                p: 'BRE',
                                t: 'TA',
                            },
                            options: true,
                            style: {},
                            value: 'FOR Debiti operaz. societ.',
                            visible: true,
                        },
                        {
                            children: [],
                            disabled: false,
                            expandable: false,
                            icon: 'favorite',
                            isExpanded: false,
                            obj: {
                                k: 'LOCEXD',
                                p: 'B£AMO',
                                t: 'TA',
                            },
                            options: true,
                            style: {},
                            isStaff: true,
                            value: 'Staff 1',
                            visible: true,
                        },
                        {
                            children: [],
                            disabled: false,
                            expandable: false,
                            icon: 'favorite',
                            isExpanded: false,
                            obj: {
                                k: 'LOCEXD',
                                p: 'B£AMO',
                                t: 'TA',
                            },
                            options: true,
                            style: {},
                            isStaff: true,
                            value: 'Staff 2',
                            visible: true,
                        },
                        {
                            children: [],
                            disabled: false,
                            expandable: false,
                            icon: 'table-large',
                            id: 'AGE',
                            isExpanded: false,
                            isWeird: true,
                            obj: {
                                k: 'AGE',
                                p: 'BRE',
                                t: 'TA',
                            },
                            options: true,
                            style: {},
                            value: 'Agente',
                            visible: true,
                        },
                        {
                            children: [
                                {
                                    children: [],
                                    disabled: false,
                                    expandable: false,
                                    icon: 'favorite',
                                    id: 'LOCTML',
                                    isExpanded: false,
                                    obj: {
                                        k: 'LOCTML',
                                        p: 'B£AMO',
                                        t: 'TA',
                                    },
                                    options: true,
                                    style: {},
                                    value: 'Timeline',
                                    visible: true,
                                },
                                {
                                    children: [],
                                    disabled: false,
                                    expandable: false,
                                    icon: 'favorite',
                                    isExpanded: false,
                                    obj: {
                                        k: 'LOCEXD',
                                        p: 'B£AMO',
                                        t: 'TA',
                                    },
                                    options: true,
                                    style: {},
                                    isStaff: true,
                                    value: 'Staff 1',
                                    visible: true,
                                },
                                {
                                    children: [],
                                    disabled: false,
                                    expandable: false,
                                    icon: 'favorite',
                                    isExpanded: false,
                                    obj: {
                                        k: 'LOCEXD',
                                        p: 'B£AMO',
                                        t: 'TA',
                                    },
                                    options: true,
                                    style: {},
                                    isStaff: true,
                                    value: 'Staff 2',
                                    visible: true,
                                },
                                {
                                    children: [],
                                    disabled: false,
                                    expandable: false,
                                    icon: 'favorite',
                                    isExpanded: false,
                                    obj: {
                                        k: 'LOCTML',
                                        p: 'B£AMO',
                                        t: 'TA',
                                    },
                                    options: true,
                                    style: {},
                                    value: 'Timeline',
                                    visible: true,
                                },
                            ],
                            disabled: false,
                            expandable: true,
                            icon: 'table-large',
                            id: 'BAN',
                            isExpanded: true,
                            obj: {
                                k: 'BAN',
                                p: 'BRE',
                                t: 'TA',
                            },
                            options: true,
                            style: {},
                            value: 'Banche',
                            visible: true,
                        },
                    ],
                    disabled: false,
                    expandable: true,
                    icon: 'table-large',
                    id: '03',
                    isExpanded: true,
                    obj: {
                        k: '03',
                        p: 'V§R',
                        t: 'TA',
                    },
                    options: true,
                    style: {},
                    value: 'Lombardia',
                    visible: true,
                },
                {
                    children: [],
                    disabled: false,
                    expandable: false,
                    icon: 'favorite',
                    isExpanded: false,
                    obj: {
                        k: 'LOCEXD',
                        p: 'B£AMO',
                        t: 'TA',
                    },
                    options: true,
                    style: {},
                    isStaff: true,
                    value: 'Staff 1',
                    visible: true,
                },
                {
                    children: [],
                    disabled: false,
                    expandable: false,
                    icon: 'favorite',
                    isExpanded: false,
                    obj: {
                        k: 'LOCEXD',
                        p: 'B£AMO',
                        t: 'TA',
                    },
                    options: true,
                    style: {},
                    isStaff: true,
                    value: 'Staff 2',
                    visible: true,
                },
                {
                    children: [],
                    disabled: false,
                    expandable: false,
                    icon: 'table-large',
                    id: '14',
                    isExpanded: false,
                    obj: {
                        k: '14',
                        p: 'V§R',
                        t: 'TA',
                    },
                    options: true,
                    style: {},
                    value: 'Molise',
                    visible: true,
                },
            ],
            disabled: false,
            expandable: true,
            icon: 'account',
            id: 'D0',
            isExpanded: false,
            obj: {
                k: 'D0',
                p: 'B£A',
                t: 'TA',
            },
            options: true,
            style: {},
            value: 'AcosUP Costi Avanzati',
            visible: true,
        },
    ],
};

const dataLayout = {
    columns: [
        {
            isKey: false,
            name: 'R§CDPA',
            title: 'Codice Padre',
            tooltip: true,
        },
        {
            decimals: 0,
            isKey: false,
            name: 'NCOL',
            obj: {
                k: '',
                p: '',
                t: 'NR',
            },
            title: 'Numero\nCollaboratori',
            tooltip: false,
        },
        {
            decimals: 2,
            isKey: false,
            name: 'NFTE',
            obj: {
                k: '',
                p: '',
                t: 'NR',
            },
            title: 'Numero\nCollaboratori\nFTE',
            tooltip: false,
        },
    ],
    rows: [
        {
            cells: {
                'R§TPPA': {
                    cssClass: 'strong-text top-right-indicator',
                    isEditable: false,
                    obj: {
                        k: '',
                        p: '',
                        t: 'OG',
                    },
                    value: '',
                },
                NCOL: {
                    isEditable: false,
                    obj: {
                        k: '0',
                        p: '',
                        t: 'NR',
                    },
                    value: '',
                },
                'R§CDPA': {
                    cssClass: ' top-right-indicator',
                    isEditable: false,
                    obj: {
                        k: '',
                        p: '',
                        t: '',
                    },
                    value: '',
                },
                NFTE: {
                    isEditable: false,
                    obj: {
                        k: '0',
                        p: '',
                        t: 'NR',
                    },
                    value: '',
                },
            },
            children: [
                {
                    cells: {
                        'R§TPPA': {
                            cssClass: 'strong-text top-right-indicator',
                            isEditable: false,
                            obj: {
                                k: 'CNAZI       ',
                                p: '',
                                t: 'OG',
                            },
                            value: 'CNAZI       ',
                        },
                        NCOL: {
                            isEditable: false,
                            obj: {
                                k: '0',
                                p: '',
                                t: 'NR',
                            },
                            value: '',
                        },
                        'R§CDPA': {
                            cssClass: 'strong-text top-right-indicator',
                            isEditable: false,
                            obj: {
                                k: '10',
                                p: 'AZI       ',
                                t: 'CN',
                            },
                            value: '10',
                        },
                        NFTE: {
                            isEditable: false,
                            obj: {
                                k: '0',
                                p: '',
                                t: 'NR',
                            },
                            value: '',
                        },
                    },
                    children: [
                        {
                            cells: {
                                'R§TPPA': {
                                    cssClass: 'strong-text top-right-indicator',
                                    isEditable: false,
                                    obj: {
                                        k: 'CFP0£02     ',
                                        p: '',
                                        t: 'OG',
                                    },
                                    value: 'CFP0£02     ',
                                },
                                NCOL: {
                                    isEditable: false,
                                    obj: {
                                        k: '0',
                                        p: '',
                                        t: 'NR',
                                    },
                                    value: '',
                                },
                                'R§CDPA': {
                                    cssClass: 'strong-text top-right-indicator',
                                    isEditable: false,
                                    obj: {
                                        k: 'UO69',
                                        p: 'P0£02     ',
                                        t: 'CF',
                                    },
                                    value: 'UO69',
                                },
                                NFTE: {
                                    isEditable: false,
                                    obj: {
                                        k: '0',
                                        p: '',
                                        t: 'NR',
                                    },
                                    value: '',
                                },
                            },
                            children: [
                                {
                                    cells: {
                                        'R§TPPA': {
                                            cssClass:
                                                'strong-text top-right-indicator',
                                            isEditable: false,
                                            obj: {
                                                k: 'CFP0£02     ',
                                                p: '',
                                                t: 'OG',
                                            },
                                            value: 'CFP0£02     ',
                                        },
                                        NCOL: {
                                            isEditable: false,
                                            obj: {
                                                k: '28',
                                                p: '',
                                                t: 'NR',
                                            },
                                            value: '28',
                                        },
                                        'R§CDPA': {
                                            cssClass:
                                                'strong-text top-right-indicator',
                                            isEditable: false,
                                            obj: {
                                                k: 'UO70           ',
                                                p: 'P0£02     ',
                                                t: 'CF',
                                            },
                                            value: 'UO70           ',
                                        },
                                        NFTE: {
                                            isEditable: false,
                                            obj: {
                                                k: '23.620',
                                                p: '',
                                                t: 'NR',
                                            },
                                            value: '23.62',
                                        },
                                    },
                                    children: [],
                                    disabled: false,
                                    expandable: false,
                                    icon: 'layers',
                                    id: 'PO72',
                                    isExpanded: false,
                                    obj: {
                                        k: 'PO72',
                                        p: 'P0£03',
                                        t: 'CF',
                                    },
                                    options: true,
                                    style: {},
                                    value: 'PO72: BSA Programmatore',
                                },
                                {
                                    cells: {
                                        'R§TPPA': {
                                            cssClass:
                                                'strong-text top-right-indicator',
                                            isEditable: false,
                                            obj: {
                                                k: 'CFP0£02     ',
                                                p: '',
                                                t: 'OG',
                                            },
                                            value: 'CFP0£02     ',
                                        },
                                        NCOL: {
                                            isEditable: false,
                                            obj: {
                                                k: '65',
                                                p: '',
                                                t: 'NR',
                                            },
                                            value: '65',
                                        },
                                        'R§CDPA': {
                                            cssClass:
                                                'strong-text top-right-indicator',
                                            isEditable: false,
                                            obj: {
                                                k: 'UO70           ',
                                                p: 'P0£02     ',
                                                t: 'CF',
                                            },
                                            value: 'UO70           ',
                                        },
                                        NFTE: {
                                            isEditable: false,
                                            obj: {
                                                k: '52.200',
                                                p: '',
                                                t: 'NR',
                                            },
                                            value: '52.20',
                                        },
                                    },
                                    children: [],
                                    disabled: false,
                                    expandable: false,
                                    icon: 'layers',
                                    id: 'PO71',
                                    isExpanded: false,
                                    obj: {
                                        k: 'PO71',
                                        p: 'P0£03',
                                        t: 'CF',
                                    },
                                    options: true,
                                    style: {},
                                    value: 'PO71: BSA Analista Programmatore',
                                },
                                {
                                    cells: {
                                        'R§TPPA': {
                                            cssClass:
                                                'strong-text top-right-indicator',
                                            isEditable: false,
                                            obj: {
                                                k: 'CFP0£02     ',
                                                p: '',
                                                t: 'OG',
                                            },
                                            value: 'CFP0£02     ',
                                        },
                                        NCOL: {
                                            isEditable: false,
                                            obj: {
                                                k: '30',
                                                p: '',
                                                t: 'NR',
                                            },
                                            value: '30',
                                        },
                                        'R§CDPA': {
                                            cssClass:
                                                'strong-text top-right-indicator',
                                            isEditable: false,
                                            obj: {
                                                k: 'UO70           ',
                                                p: 'P0£02     ',
                                                t: 'CF',
                                            },
                                            value: 'UO70           ',
                                        },
                                        NFTE: {
                                            isEditable: false,
                                            obj: {
                                                k: '28.700',
                                                p: '',
                                                t: 'NR',
                                            },
                                            value: '28.70',
                                        },
                                    },
                                    children: [],
                                    disabled: false,
                                    expandable: false,
                                    icon: 'layers',
                                    id: 'PO69',
                                    isExpanded: false,
                                    obj: {
                                        k: 'PO69',
                                        p: 'P0£03',
                                        t: 'CF',
                                    },
                                    options: true,
                                    style: {},
                                    value: 'PO69: BSA Capo Progetto',
                                },
                                {
                                    cells: {
                                        'R§TPPA': {
                                            cssClass:
                                                'strong-text top-right-indicator',
                                            isEditable: false,
                                            obj: {
                                                k: 'CFP0£02     ',
                                                p: '',
                                                t: 'OG',
                                            },
                                            value: 'CFP0£02     ',
                                        },
                                        NCOL: {
                                            isEditable: false,
                                            obj: {
                                                k: '63',
                                                p: '',
                                                t: 'NR',
                                            },
                                            value: '63',
                                        },
                                        'R§CDPA': {
                                            cssClass:
                                                'strong-text top-right-indicator',
                                            isEditable: false,
                                            obj: {
                                                k: 'UO70           ',
                                                p: 'P0£02     ',
                                                t: 'CF',
                                            },
                                            value: 'UO70           ',
                                        },
                                        NFTE: {
                                            isEditable: false,
                                            obj: {
                                                k: '52.840',
                                                p: '',
                                                t: 'NR',
                                            },
                                            value: '52.84',
                                        },
                                    },
                                    children: [],
                                    disabled: false,
                                    expandable: false,
                                    icon: 'layers',
                                    id: 'PO70',
                                    isExpanded: false,
                                    obj: {
                                        k: 'PO70',
                                        p: 'P0£03',
                                        t: 'CF',
                                    },
                                    options: true,
                                    style: {},
                                    value: 'PO70: BSA Consulente Applicativo',
                                },
                                {
                                    cells: {
                                        'R§TPPA': {
                                            cssClass:
                                                'strong-text top-right-indicator',
                                            isEditable: false,
                                            obj: {
                                                k: 'CFP0£02     ',
                                                p: '',
                                                t: 'OG',
                                            },
                                            value: 'CFP0£02     ',
                                        },
                                        NCOL: {
                                            isEditable: false,
                                            obj: {
                                                k: '9',
                                                p: '',
                                                t: 'NR',
                                            },
                                            value: '9',
                                        },
                                        'R§CDPA': {
                                            cssClass:
                                                'strong-text top-right-indicator',
                                            isEditable: false,
                                            obj: {
                                                k: 'UO70           ',
                                                p: 'P0£02     ',
                                                t: 'CF',
                                            },
                                            value: 'UO70           ',
                                        },
                                        NFTE: {
                                            isEditable: false,
                                            obj: {
                                                k: '9.000',
                                                p: '',
                                                t: 'NR',
                                            },
                                            value: '9.00',
                                        },
                                    },
                                    children: [],
                                    disabled: false,
                                    expandable: false,
                                    icon: 'layers',
                                    id: 'PO68',
                                    isExpanded: false,
                                    obj: {
                                        k: 'PO68',
                                        p: 'P0£03',
                                        t: 'CF',
                                    },
                                    options: true,
                                    style: {},
                                    value: 'PO68: BSA Manager II Livello',
                                },
                                {
                                    cells: {
                                        'R§TPPA': {
                                            cssClass:
                                                'strong-text top-right-indicator',
                                            isEditable: false,
                                            obj: {
                                                k: 'CFP0£02     ',
                                                p: '',
                                                t: 'OG',
                                            },
                                            value: 'CFP0£02     ',
                                        },
                                        NCOL: {
                                            isEditable: false,
                                            obj: {
                                                k: '2',
                                                p: '',
                                                t: 'NR',
                                            },
                                            value: '2',
                                        },
                                        'R§CDPA': {
                                            cssClass:
                                                'strong-text top-right-indicator',
                                            isEditable: false,
                                            obj: {
                                                k: 'UO70           ',
                                                p: 'P0£02     ',
                                                t: 'CF',
                                            },
                                            value: 'UO70           ',
                                        },
                                        NFTE: {
                                            isEditable: false,
                                            obj: {
                                                k: '1.750',
                                                p: '',
                                                t: 'NR',
                                            },
                                            value: '1.75',
                                        },
                                    },
                                    children: [],
                                    disabled: false,
                                    expandable: false,
                                    icon: 'layers',
                                    id: 'PO73',
                                    isExpanded: false,
                                    obj: {
                                        k: 'PO73',
                                        p: 'P0£03',
                                        t: 'CF',
                                    },
                                    options: true,
                                    style: {},
                                    value: 'PO73: BSA Customer Care Specialist',
                                },
                            ],
                            disabled: false,
                            expandable: true,
                            icon: 'layers',
                            id: 'UO70',
                            isExpanded: true,
                            obj: {
                                k: 'UO70',
                                p: 'P0£02',
                                t: 'CF',
                            },
                            options: true,
                            style: {},
                            value: 'UO70: CIRONE ROBERTO - BSA Delivery',
                        },
                        {
                            cells: {
                                'R§TPPA': {
                                    cssClass: 'strong-text top-right-indicator',
                                    isEditable: false,
                                    obj: {
                                        k: 'CFP0£02     ',
                                        p: '',
                                        t: 'OG',
                                    },
                                    value: 'CFP0£02     ',
                                },
                                NCOL: {
                                    isEditable: false,
                                    obj: {
                                        k: '0',
                                        p: '',
                                        t: 'NR',
                                    },
                                    value: '',
                                },
                                'R§CDPA': {
                                    cssClass: 'strong-text top-right-indicator',
                                    isEditable: false,
                                    obj: {
                                        k: 'UO69',
                                        p: 'P0£02     ',
                                        t: 'CF',
                                    },
                                    value: 'UO69',
                                },
                                NFTE: {
                                    isEditable: false,
                                    obj: {
                                        k: '0',
                                        p: '',
                                        t: 'NR',
                                    },
                                    value: '',
                                },
                            },
                            children: [
                                {
                                    cells: {
                                        'R§TPPA': {
                                            cssClass:
                                                'strong-text top-right-indicator',
                                            isEditable: false,
                                            obj: {
                                                k: 'CFP0£02     ',
                                                p: '',
                                                t: 'OG',
                                            },
                                            value: 'CFP0£02     ',
                                        },
                                        NCOL: {
                                            isEditable: false,
                                            obj: {
                                                k: '7',
                                                p: '',
                                                t: 'NR',
                                            },
                                            value: '7',
                                        },
                                        'R§CDPA': {
                                            cssClass:
                                                'strong-text top-right-indicator',
                                            isEditable: false,
                                            obj: {
                                                k: 'UO71           ',
                                                p: 'P0£02     ',
                                                t: 'CF',
                                            },
                                            value: 'UO71           ',
                                        },
                                        NFTE: {
                                            isEditable: false,
                                            obj: {
                                                k: '6.250',
                                                p: '',
                                                t: 'NR',
                                            },
                                            value: '6.25',
                                        },
                                    },
                                    children: [],
                                    disabled: false,
                                    expandable: false,
                                    icon: 'layers',
                                    id: 'PO74',
                                    isExpanded: false,
                                    obj: {
                                        k: 'PO74',
                                        p: 'P0£03',
                                        t: 'CF',
                                    },
                                    options: true,
                                    style: {},
                                    value: 'PO74: BSA Back Office Specialist',
                                },
                            ],
                            disabled: false,
                            expandable: true,
                            icon: 'layers',
                            id: 'UO71',
                            isExpanded: true,
                            obj: {
                                k: 'UO71',
                                p: 'P0£02',
                                t: 'CF',
                            },
                            options: true,
                            style: {},
                            value: 'UO71: DELLAVIA MASSIMO - BSA Back Office',
                        },
                        {
                            cells: {
                                'R§TPPA': {
                                    cssClass: 'strong-text top-right-indicator',
                                    isEditable: false,
                                    obj: {
                                        k: 'CFP0£02     ',
                                        p: '',
                                        t: 'OG',
                                    },
                                    value: 'CFP0£02     ',
                                },
                                NCOL: {
                                    isEditable: false,
                                    obj: {
                                        k: '0',
                                        p: '',
                                        t: 'NR',
                                    },
                                    value: '',
                                },
                                'R§CDPA': {
                                    cssClass: 'strong-text top-right-indicator',
                                    isEditable: false,
                                    obj: {
                                        k: 'UO69',
                                        p: 'P0£02     ',
                                        t: 'CF',
                                    },
                                    value: 'UO69',
                                },
                                NFTE: {
                                    isEditable: false,
                                    obj: {
                                        k: '0',
                                        p: '',
                                        t: 'NR',
                                    },
                                    value: '',
                                },
                            },
                            children: [
                                {
                                    cells: {
                                        'R§TPPA': {
                                            cssClass:
                                                'strong-text top-right-indicator',
                                            isEditable: false,
                                            obj: {
                                                k: 'CFP0£02     ',
                                                p: '',
                                                t: 'OG',
                                            },
                                            value: 'CFP0£02     ',
                                        },
                                        NCOL: {
                                            isEditable: false,
                                            obj: {
                                                k: '15',
                                                p: '',
                                                t: 'NR',
                                            },
                                            value: '15',
                                        },
                                        'R§CDPA': {
                                            cssClass:
                                                'strong-text top-right-indicator',
                                            isEditable: false,
                                            obj: {
                                                k: 'UO72           ',
                                                p: 'P0£02     ',
                                                t: 'CF',
                                            },
                                            value: 'UO72           ',
                                        },
                                        NFTE: {
                                            isEditable: false,
                                            obj: {
                                                k: '14.200',
                                                p: '',
                                                t: 'NR',
                                            },
                                            value: '14.20',
                                        },
                                    },
                                    children: [],
                                    disabled: false,
                                    expandable: false,
                                    icon: 'layers',
                                    id: 'PO76',
                                    isExpanded: false,
                                    obj: {
                                        k: 'PO76',
                                        p: 'P0£03',
                                        t: 'CF',
                                    },
                                    options: true,
                                    style: {},
                                    value: 'PO76: BSA Sales Account',
                                },
                                {
                                    cells: {
                                        'R§TPPA': {
                                            cssClass:
                                                'strong-text top-right-indicator',
                                            isEditable: false,
                                            obj: {
                                                k: 'CFP0£02     ',
                                                p: '',
                                                t: 'OG',
                                            },
                                            value: 'CFP0£02     ',
                                        },
                                        NCOL: {
                                            isEditable: false,
                                            obj: {
                                                k: '3',
                                                p: '',
                                                t: 'NR',
                                            },
                                            value: '3',
                                        },
                                        'R§CDPA': {
                                            cssClass:
                                                'strong-text top-right-indicator',
                                            isEditable: false,
                                            obj: {
                                                k: 'UO72           ',
                                                p: 'P0£02     ',
                                                t: 'CF',
                                            },
                                            value: 'UO72           ',
                                        },
                                        NFTE: {
                                            isEditable: false,
                                            obj: {
                                                k: '3.000',
                                                p: '',
                                                t: 'NR',
                                            },
                                            value: '3.00',
                                        },
                                    },
                                    children: [],
                                    disabled: false,
                                    expandable: false,
                                    icon: 'layers',
                                    id: 'PO75',
                                    isExpanded: false,
                                    obj: {
                                        k: 'PO75',
                                        p: 'P0£03',
                                        t: 'CF',
                                    },
                                    options: true,
                                    style: {},
                                    value: 'PO75: BSA Area Manager',
                                },
                            ],
                            disabled: false,
                            expandable: true,
                            icon: 'layers',
                            id: 'UO72',
                            isExpanded: true,
                            obj: {
                                k: 'UO72',
                                p: 'P0£02',
                                t: 'CF',
                            },
                            options: true,
                            style: {},
                            value: 'UO72: SIGNORINI DOMENICO - BSA Vendite',
                        },
                        {
                            cells: {
                                'R§TPPA': {
                                    cssClass: 'strong-text top-right-indicator',
                                    isEditable: false,
                                    obj: {
                                        k: 'CFP0£02     ',
                                        p: '',
                                        t: 'OG',
                                    },
                                    value: 'CFP0£02     ',
                                },
                                NCOL: {
                                    isEditable: false,
                                    obj: {
                                        k: '0',
                                        p: '',
                                        t: 'NR',
                                    },
                                    value: '',
                                },
                                'R§CDPA': {
                                    cssClass: 'strong-text top-right-indicator',
                                    isEditable: false,
                                    obj: {
                                        k: 'UO69',
                                        p: 'P0£02     ',
                                        t: 'CF',
                                    },
                                    value: 'UO69',
                                },
                                NFTE: {
                                    isEditable: false,
                                    obj: {
                                        k: '0',
                                        p: '',
                                        t: 'NR',
                                    },
                                    value: '',
                                },
                            },
                            children: [
                                {
                                    cells: {
                                        'R§TPPA': {
                                            cssClass:
                                                'strong-text top-right-indicator',
                                            isEditable: false,
                                            obj: {
                                                k: 'CFP0£02     ',
                                                p: '',
                                                t: 'OG',
                                            },
                                            value: 'CFP0£02     ',
                                        },
                                        NCOL: {
                                            isEditable: false,
                                            obj: {
                                                k: '0',
                                                p: '',
                                                t: 'NR',
                                            },
                                            value: '',
                                        },
                                        'R§CDPA': {
                                            cssClass:
                                                'strong-text top-right-indicator',
                                            isEditable: false,
                                            obj: {
                                                k: 'UO73',
                                                p: 'P0£02     ',
                                                t: 'CF',
                                            },
                                            value: 'UO73',
                                        },
                                        NFTE: {
                                            isEditable: false,
                                            obj: {
                                                k: '0',
                                                p: '',
                                                t: 'NR',
                                            },
                                            value: '',
                                        },
                                    },
                                    children: [
                                        {
                                            cells: {
                                                'R§TPPA': {
                                                    cssClass:
                                                        'strong-text top-right-indicator',
                                                    isEditable: false,
                                                    obj: {
                                                        k: 'CFP0£02     ',
                                                        p: '',
                                                        t: 'OG',
                                                    },
                                                    value: 'CFP0£02     ',
                                                },
                                                NCOL: {
                                                    isEditable: false,
                                                    obj: {
                                                        k: '0',
                                                        p: '',
                                                        t: 'NR',
                                                    },
                                                    value: '',
                                                },
                                                'R§CDPA': {
                                                    cssClass:
                                                        'strong-text top-right-indicator',
                                                    isEditable: false,
                                                    obj: {
                                                        k: 'UO74',
                                                        p: 'P0£02     ',
                                                        t: 'CF',
                                                    },
                                                    value: 'UO74',
                                                },
                                                NFTE: {
                                                    isEditable: false,
                                                    obj: {
                                                        k: '0',
                                                        p: '',
                                                        t: 'NR',
                                                    },
                                                    value: '',
                                                },
                                            },
                                            children: [
                                                {
                                                    cells: {
                                                        'R§TPPA': {
                                                            cssClass:
                                                                'strong-text top-right-indicator',
                                                            isEditable: false,
                                                            obj: {
                                                                k: 'CFP0£02     ',
                                                                p: '',
                                                                t: 'OG',
                                                            },
                                                            value: 'CFP0£02     ',
                                                        },
                                                        NCOL: {
                                                            isEditable: false,
                                                            obj: {
                                                                k: '1',
                                                                p: '',
                                                                t: 'NR',
                                                            },
                                                            value: '1',
                                                        },
                                                        'R§CDPA': {
                                                            cssClass:
                                                                'strong-text top-right-indicator',
                                                            isEditable: false,
                                                            obj: {
                                                                k: 'UO77           ',
                                                                p: 'P0£02     ',
                                                                t: 'CF',
                                                            },
                                                            value: 'UO77           ',
                                                        },
                                                        NFTE: {
                                                            isEditable: false,
                                                            obj: {
                                                                k: '1.000',
                                                                p: '',
                                                                t: 'NR',
                                                            },
                                                            value: '1.00',
                                                        },
                                                    },
                                                    children: [],
                                                    disabled: false,
                                                    expandable: false,
                                                    icon: 'layers',
                                                    id: 'PO78',
                                                    isExpanded: false,
                                                    obj: {
                                                        k: 'PO78',
                                                        p: 'P0£03',
                                                        t: 'CF',
                                                    },
                                                    options: true,
                                                    style: {},
                                                    value: 'PO78: BSA Analista Programmatore IOT',
                                                },
                                                {
                                                    cells: {
                                                        'R§TPPA': {
                                                            cssClass:
                                                                'strong-text top-right-indicator',
                                                            isEditable: false,
                                                            obj: {
                                                                k: 'CFP0£02     ',
                                                                p: '',
                                                                t: 'OG',
                                                            },
                                                            value: 'CFP0£02     ',
                                                        },
                                                        NCOL: {
                                                            isEditable: false,
                                                            obj: {
                                                                k: '1',
                                                                p: '',
                                                                t: 'NR',
                                                            },
                                                            value: '1',
                                                        },
                                                        'R§CDPA': {
                                                            cssClass:
                                                                'strong-text top-right-indicator',
                                                            isEditable: false,
                                                            obj: {
                                                                k: 'UO77           ',
                                                                p: 'P0£02     ',
                                                                t: 'CF',
                                                            },
                                                            value: 'UO77           ',
                                                        },
                                                        NFTE: {
                                                            isEditable: false,
                                                            obj: {
                                                                k: '1.000',
                                                                p: '',
                                                                t: 'NR',
                                                            },
                                                            value: '1.00',
                                                        },
                                                    },
                                                    children: [],
                                                    disabled: false,
                                                    expandable: false,
                                                    icon: 'layers',
                                                    id: 'PO77',
                                                    isExpanded: false,
                                                    obj: {
                                                        k: 'PO77',
                                                        p: 'P0£03',
                                                        t: 'CF',
                                                    },
                                                    options: true,
                                                    style: {},
                                                    value: 'PO77: BSA Consulente Applicativo IOT',
                                                },
                                                {
                                                    cells: {
                                                        'R§TPPA': {
                                                            cssClass:
                                                                'strong-text top-right-indicator',
                                                            isEditable: false,
                                                            obj: {
                                                                k: 'CFP0£02     ',
                                                                p: '',
                                                                t: 'OG',
                                                            },
                                                            value: 'CFP0£02     ',
                                                        },
                                                        NCOL: {
                                                            isEditable: false,
                                                            obj: {
                                                                k: '1',
                                                                p: '',
                                                                t: 'NR',
                                                            },
                                                            value: '1',
                                                        },
                                                        'R§CDPA': {
                                                            cssClass:
                                                                'strong-text top-right-indicator',
                                                            isEditable: false,
                                                            obj: {
                                                                k: 'UO77           ',
                                                                p: 'P0£02     ',
                                                                t: 'CF',
                                                            },
                                                            value: 'UO77           ',
                                                        },
                                                        NFTE: {
                                                            isEditable: false,
                                                            obj: {
                                                                k: '1.000',
                                                                p: '',
                                                                t: 'NR',
                                                            },
                                                            value: '1.00',
                                                        },
                                                    },
                                                    children: [],
                                                    disabled: false,
                                                    expandable: false,
                                                    icon: 'layers',
                                                    id: 'PO79',
                                                    isExpanded: false,
                                                    obj: {
                                                        k: 'PO79',
                                                        p: 'P0£03',
                                                        t: 'CF',
                                                    },
                                                    options: true,
                                                    style: {},
                                                    value: 'PO79: BSA Programmatore IOT',
                                                },
                                            ],
                                            disabled: false,
                                            expandable: true,
                                            icon: 'layers',
                                            id: 'UO77',
                                            isExpanded: true,
                                            obj: {
                                                k: 'UO77',
                                                p: 'P0£02',
                                                t: 'CF',
                                            },
                                            options: true,
                                            style: {},
                                            value: 'UO77: - BSA Delivery IoT',
                                        },
                                    ],
                                    disabled: false,
                                    expandable: true,
                                    icon: 'layers',
                                    id: 'UO74',
                                    isExpanded: true,
                                    obj: {
                                        k: 'UO74',
                                        p: 'P0£02',
                                        t: 'CF',
                                    },
                                    options: true,
                                    style: {},
                                    value: 'UO74: BOSOTTI STEFANO - BSA LOB IoT',
                                },
                                {
                                    cells: {
                                        'R§TPPA': {
                                            cssClass:
                                                'strong-text top-right-indicator',
                                            isEditable: false,
                                            obj: {
                                                k: 'CFP0£02     ',
                                                p: '',
                                                t: 'OG',
                                            },
                                            value: 'CFP0£02     ',
                                        },
                                        NCOL: {
                                            isEditable: false,
                                            obj: {
                                                k: '0',
                                                p: '',
                                                t: 'NR',
                                            },
                                            value: '',
                                        },
                                        'R§CDPA': {
                                            cssClass:
                                                'strong-text top-right-indicator',
                                            isEditable: false,
                                            obj: {
                                                k: 'UO73',
                                                p: 'P0£02     ',
                                                t: 'CF',
                                            },
                                            value: 'UO73',
                                        },
                                        NFTE: {
                                            isEditable: false,
                                            obj: {
                                                k: '0',
                                                p: '',
                                                t: 'NR',
                                            },
                                            value: '',
                                        },
                                    },
                                    children: [
                                        {
                                            cells: {
                                                'R§TPPA': {
                                                    cssClass:
                                                        'strong-text top-right-indicator',
                                                    isEditable: false,
                                                    obj: {
                                                        k: 'CFP0£02     ',
                                                        p: '',
                                                        t: 'OG',
                                                    },
                                                    value: 'CFP0£02     ',
                                                },
                                                NCOL: {
                                                    isEditable: false,
                                                    obj: {
                                                        k: '0',
                                                        p: '',
                                                        t: 'NR',
                                                    },
                                                    value: '',
                                                },
                                                'R§CDPA': {
                                                    cssClass:
                                                        'strong-text top-right-indicator',
                                                    isEditable: false,
                                                    obj: {
                                                        k: 'UO75',
                                                        p: 'P0£02     ',
                                                        t: 'CF',
                                                    },
                                                    value: 'UO75',
                                                },
                                                NFTE: {
                                                    isEditable: false,
                                                    obj: {
                                                        k: '0',
                                                        p: '',
                                                        t: 'NR',
                                                    },
                                                    value: '',
                                                },
                                            },
                                            children: [
                                                {
                                                    cells: {
                                                        'R§TPPA': {
                                                            cssClass:
                                                                'strong-text top-right-indicator',
                                                            isEditable: false,
                                                            obj: {
                                                                k: 'CFP0£02     ',
                                                                p: '',
                                                                t: 'OG',
                                                            },
                                                            value: 'CFP0£02     ',
                                                        },
                                                        NCOL: {
                                                            isEditable: false,
                                                            obj: {
                                                                k: '4',
                                                                p: '',
                                                                t: 'NR',
                                                            },
                                                            value: '4',
                                                        },
                                                        'R§CDPA': {
                                                            cssClass:
                                                                'strong-text top-right-indicator',
                                                            isEditable: false,
                                                            obj: {
                                                                k: 'UO78           ',
                                                                p: 'P0£02     ',
                                                                t: 'CF',
                                                            },
                                                            value: 'UO78           ',
                                                        },
                                                        NFTE: {
                                                            isEditable: false,
                                                            obj: {
                                                                k: '3.750',
                                                                p: '',
                                                                t: 'NR',
                                                            },
                                                            value: '3.75',
                                                        },
                                                    },
                                                    children: [],
                                                    disabled: false,
                                                    expandable: false,
                                                    icon: 'layers',
                                                    id: 'PO80',
                                                    isExpanded: false,
                                                    obj: {
                                                        k: 'PO80',
                                                        p: 'P0£03',
                                                        t: 'CF',
                                                    },
                                                    options: true,
                                                    style: {},
                                                    value: 'PO80: BSA Consulente Applicativo B',
                                                },
                                            ],
                                            disabled: false,
                                            expandable: true,
                                            icon: 'layers',
                                            id: 'UO78',
                                            isExpanded: true,
                                            obj: {
                                                k: 'UO78',
                                                p: 'P0£02',
                                                t: 'CF',
                                            },
                                            options: true,
                                            style: {},
                                            value: 'UO78: - BSA Delivery BI',
                                        },
                                    ],
                                    disabled: false,
                                    expandable: true,
                                    icon: 'layers',
                                    id: 'UO75',
                                    isExpanded: true,
                                    obj: {
                                        k: 'UO75',
                                        p: 'P0£02',
                                        t: 'CF',
                                    },
                                    options: true,
                                    style: {},
                                    value: 'UO75: POZZI ALBERTO - BSA LOB BI',
                                },
                                {
                                    cells: {
                                        'R§TPPA': {
                                            cssClass:
                                                'strong-text top-right-indicator',
                                            isEditable: false,
                                            obj: {
                                                k: 'CFP0£02     ',
                                                p: '',
                                                t: 'OG',
                                            },
                                            value: 'CFP0£02     ',
                                        },
                                        NCOL: {
                                            isEditable: false,
                                            obj: {
                                                k: '0',
                                                p: '',
                                                t: 'NR',
                                            },
                                            value: '',
                                        },
                                        'R§CDPA': {
                                            cssClass:
                                                'strong-text top-right-indicator',
                                            isEditable: false,
                                            obj: {
                                                k: 'UO73',
                                                p: 'P0£02     ',
                                                t: 'CF',
                                            },
                                            value: 'UO73',
                                        },
                                        NFTE: {
                                            isEditable: false,
                                            obj: {
                                                k: '0',
                                                p: '',
                                                t: 'NR',
                                            },
                                            value: '',
                                        },
                                    },
                                    children: [
                                        {
                                            cells: {
                                                'R§TPPA': {
                                                    cssClass:
                                                        'strong-text top-right-indicator',
                                                    isEditable: false,
                                                    obj: {
                                                        k: 'CFP0£02     ',
                                                        p: '',
                                                        t: 'OG',
                                                    },
                                                    value: 'CFP0£02     ',
                                                },
                                                NCOL: {
                                                    isEditable: false,
                                                    obj: {
                                                        k: '0',
                                                        p: '',
                                                        t: 'NR',
                                                    },
                                                    value: '',
                                                },
                                                'R§CDPA': {
                                                    cssClass:
                                                        'strong-text top-right-indicator',
                                                    isEditable: false,
                                                    obj: {
                                                        k: 'UO76',
                                                        p: 'P0£02     ',
                                                        t: 'CF',
                                                    },
                                                    value: 'UO76',
                                                },
                                                NFTE: {
                                                    isEditable: false,
                                                    obj: {
                                                        k: '0',
                                                        p: '',
                                                        t: 'NR',
                                                    },
                                                    value: '',
                                                },
                                            },
                                            children: [
                                                {
                                                    cells: {
                                                        'R§TPPA': {
                                                            cssClass:
                                                                'strong-text top-right-indicator',
                                                            isEditable: false,
                                                            obj: {
                                                                k: 'CFP0£02     ',
                                                                p: '',
                                                                t: 'OG',
                                                            },
                                                            value: 'CFP0£02     ',
                                                        },
                                                        NCOL: {
                                                            isEditable: false,
                                                            obj: {
                                                                k: '4',
                                                                p: '',
                                                                t: 'NR',
                                                            },
                                                            value: '4',
                                                        },
                                                        'R§CDPA': {
                                                            cssClass:
                                                                'strong-text top-right-indicator',
                                                            isEditable: false,
                                                            obj: {
                                                                k: 'UO79           ',
                                                                p: 'P0£02     ',
                                                                t: 'CF',
                                                            },
                                                            value: 'UO79           ',
                                                        },
                                                        NFTE: {
                                                            isEditable: false,
                                                            obj: {
                                                                k: '3.620',
                                                                p: '',
                                                                t: 'NR',
                                                            },
                                                            value: '3.62',
                                                        },
                                                    },
                                                    children: [],
                                                    disabled: false,
                                                    expandable: false,
                                                    icon: 'layers',
                                                    id: 'PO83',
                                                    isExpanded: false,
                                                    obj: {
                                                        k: 'PO83',
                                                        p: 'P0£03',
                                                        t: 'CF',
                                                    },
                                                    options: true,
                                                    style: {},
                                                    value: 'PO83: BSA Analista Programmatore DMT',
                                                },
                                                {
                                                    cells: {
                                                        'R§TPPA': {
                                                            cssClass:
                                                                'strong-text top-right-indicator',
                                                            isEditable: false,
                                                            obj: {
                                                                k: 'CFP0£02     ',
                                                                p: '',
                                                                t: 'OG',
                                                            },
                                                            value: 'CFP0£02     ',
                                                        },
                                                        NCOL: {
                                                            isEditable: false,
                                                            obj: {
                                                                k: '1',
                                                                p: '',
                                                                t: 'NR',
                                                            },
                                                            value: '1',
                                                        },
                                                        'R§CDPA': {
                                                            cssClass:
                                                                'strong-text top-right-indicator',
                                                            isEditable: false,
                                                            obj: {
                                                                k: 'UO79           ',
                                                                p: 'P0£02     ',
                                                                t: 'CF',
                                                            },
                                                            value: 'UO79           ',
                                                        },
                                                        NFTE: {
                                                            isEditable: false,
                                                            obj: {
                                                                k: '1.000',
                                                                p: '',
                                                                t: 'NR',
                                                            },
                                                            value: '1.00',
                                                        },
                                                    },
                                                    children: [],
                                                    disabled: false,
                                                    expandable: false,
                                                    icon: 'layers',
                                                    id: 'PO82',
                                                    isExpanded: false,
                                                    obj: {
                                                        k: 'PO82',
                                                        p: 'P0£03',
                                                        t: 'CF',
                                                    },
                                                    options: true,
                                                    style: {},
                                                    value: 'PO82: BSA Consulente Applicativo DMT',
                                                },
                                            ],
                                            disabled: false,
                                            expandable: true,
                                            icon: 'layers',
                                            id: 'UO79',
                                            isExpanded: true,
                                            obj: {
                                                k: 'UO79',
                                                p: 'P0£02',
                                                t: 'CF',
                                            },
                                            options: true,
                                            style: {},
                                            value: 'UO79: - BSA Delivery DMT',
                                        },
                                        {
                                            cells: {
                                                'R§TPPA': {
                                                    cssClass:
                                                        'strong-text top-right-indicator',
                                                    isEditable: false,
                                                    obj: {
                                                        k: 'CFP0£02     ',
                                                        p: '',
                                                        t: 'OG',
                                                    },
                                                    value: 'CFP0£02     ',
                                                },
                                                NCOL: {
                                                    isEditable: false,
                                                    obj: {
                                                        k: '0',
                                                        p: '',
                                                        t: 'NR',
                                                    },
                                                    value: '',
                                                },
                                                'R§CDPA': {
                                                    cssClass:
                                                        'strong-text top-right-indicator',
                                                    isEditable: false,
                                                    obj: {
                                                        k: 'UO76',
                                                        p: 'P0£02     ',
                                                        t: 'CF',
                                                    },
                                                    value: 'UO76',
                                                },
                                                NFTE: {
                                                    isEditable: false,
                                                    obj: {
                                                        k: '0',
                                                        p: '',
                                                        t: 'NR',
                                                    },
                                                    value: '',
                                                },
                                            },
                                            children: [
                                                {
                                                    cells: {
                                                        'R§TPPA': {
                                                            cssClass:
                                                                'strong-text top-right-indicator',
                                                            isEditable: false,
                                                            obj: {
                                                                k: 'CFP0£02     ',
                                                                p: '',
                                                                t: 'OG',
                                                            },
                                                            value: 'CFP0£02     ',
                                                        },
                                                        NCOL: {
                                                            isEditable: false,
                                                            obj: {
                                                                k: '1',
                                                                p: '',
                                                                t: 'NR',
                                                            },
                                                            value: '1',
                                                        },
                                                        'R§CDPA': {
                                                            cssClass:
                                                                'strong-text top-right-indicator',
                                                            isEditable: false,
                                                            obj: {
                                                                k: 'UO80           ',
                                                                p: 'P0£02     ',
                                                                t: 'CF',
                                                            },
                                                            value: 'UO80           ',
                                                        },
                                                        NFTE: {
                                                            isEditable: false,
                                                            obj: {
                                                                k: '1.000',
                                                                p: '',
                                                                t: 'NR',
                                                            },
                                                            value: '1.00',
                                                        },
                                                    },
                                                    children: [],
                                                    disabled: false,
                                                    expandable: false,
                                                    icon: 'layers',
                                                    id: 'PO84',
                                                    isExpanded: false,
                                                    obj: {
                                                        k: 'PO84',
                                                        p: 'P0£03',
                                                        t: 'CF',
                                                    },
                                                    options: true,
                                                    style: {},
                                                    value: 'PO84: BSA Sales Account DMT',
                                                },
                                            ],
                                            disabled: false,
                                            expandable: true,
                                            icon: 'layers',
                                            id: 'UO80',
                                            isExpanded: true,
                                            obj: {
                                                k: 'UO80',
                                                p: 'P0£02',
                                                t: 'CF',
                                            },
                                            options: true,
                                            style: {},
                                            value: 'UO80: - BSA Vendite DMT',
                                        },
                                        {
                                            cells: {
                                                'R§TPPA': {
                                                    cssClass:
                                                        'strong-text top-right-indicator',
                                                    isEditable: false,
                                                    obj: {
                                                        k: 'CFP0£02     ',
                                                        p: '',
                                                        t: 'OG',
                                                    },
                                                    value: 'CFP0£02     ',
                                                },
                                                NCOL: {
                                                    isEditable: false,
                                                    obj: {
                                                        k: '0',
                                                        p: '',
                                                        t: 'NR',
                                                    },
                                                    value: '',
                                                },
                                                'R§CDPA': {
                                                    cssClass:
                                                        'strong-text top-right-indicator',
                                                    isEditable: false,
                                                    obj: {
                                                        k: 'UO76',
                                                        p: 'P0£02     ',
                                                        t: 'CF',
                                                    },
                                                    value: 'UO76',
                                                },
                                                NFTE: {
                                                    isEditable: false,
                                                    obj: {
                                                        k: '0',
                                                        p: '',
                                                        t: 'NR',
                                                    },
                                                    value: '',
                                                },
                                            },
                                            children: [
                                                {
                                                    cells: {
                                                        'R§TPPA': {
                                                            cssClass:
                                                                'strong-text top-right-indicator',
                                                            isEditable: false,
                                                            obj: {
                                                                k: 'CFP0£02     ',
                                                                p: '',
                                                                t: 'OG',
                                                            },
                                                            value: 'CFP0£02     ',
                                                        },
                                                        NCOL: {
                                                            isEditable: false,
                                                            obj: {
                                                                k: '1',
                                                                p: '',
                                                                t: 'NR',
                                                            },
                                                            value: '1',
                                                        },
                                                        'R§CDPA': {
                                                            cssClass:
                                                                'strong-text top-right-indicator',
                                                            isEditable: false,
                                                            obj: {
                                                                k: 'UO73           ',
                                                                p: 'P0£02     ',
                                                                t: 'CF',
                                                            },
                                                            value: 'UO73           ',
                                                        },
                                                        NFTE: {
                                                            isEditable: false,
                                                            obj: {
                                                                k: '1.000',
                                                                p: '',
                                                                t: 'NR',
                                                            },
                                                            value: '1.00',
                                                        },
                                                    },
                                                    children: [],
                                                    disabled: false,
                                                    expandable: false,
                                                    icon: 'layers',
                                                    id: 'PO86',
                                                    isExpanded: false,
                                                    obj: {
                                                        k: 'PO86',
                                                        p: 'P0£03',
                                                        t: 'CF',
                                                    },
                                                    options: true,
                                                    style: {},
                                                    value: 'PO86: BSA Product Manager',
                                                },
                                            ],
                                            disabled: false,
                                            expandable: true,
                                            icon: 'layers',
                                            id: 'UO81',
                                            isExpanded: true,
                                            obj: {
                                                k: 'UO81',
                                                p: 'P0£02',
                                                t: 'CF',
                                            },
                                            options: true,
                                            style: {},
                                            value: 'UO81: - BSA Back Office DMT',
                                        },
                                    ],
                                    disabled: false,
                                    expandable: true,
                                    icon: 'layers',
                                    id: 'UO76',
                                    isExpanded: true,
                                    obj: {
                                        k: 'UO76',
                                        p: 'P0£02',
                                        t: 'CF',
                                    },
                                    options: true,
                                    style: {},
                                    value: 'UO76: BRUNINO PAOLO - BSA LOB DMT',
                                },
                            ],
                            disabled: false,
                            expandable: true,
                            icon: 'layers',
                            id: 'UO73',
                            isExpanded: true,
                            obj: {
                                k: 'UO73',
                                p: 'P0£02',
                                t: 'CF',
                            },
                            options: true,
                            style: {},
                            value: 'UO73: MILANI LUCA - BSA Offering',
                        },
                    ],
                    disabled: false,
                    expandable: true,
                    icon: 'layers',
                    id: 'UO69',
                    isExpanded: true,
                    obj: {
                        k: 'UO69',
                        p: 'P0£02',
                        t: 'CF',
                    },
                    options: true,
                    style: {},
                    value: 'UO69: MAGNI ROBERTO - BSA Direttore Generale',
                },
                {
                    cells: {
                        'R§TPPA': {
                            cssClass: 'strong-text top-right-indicator',
                            isEditable: false,
                            obj: {
                                k: 'CNAZI       ',
                                p: '',
                                t: 'OG',
                            },
                            value: 'CNAZI       ',
                        },
                        NCOL: {
                            isEditable: false,
                            obj: {
                                k: '0',
                                p: '',
                                t: 'NR',
                            },
                            value: '',
                        },
                        'R§CDPA': {
                            cssClass: 'strong-text top-right-indicator',
                            isEditable: false,
                            obj: {
                                k: '10',
                                p: 'AZI       ',
                                t: 'CN',
                            },
                            value: '10',
                        },
                        NFTE: {
                            isEditable: false,
                            obj: {
                                k: '0',
                                p: '',
                                t: 'NR',
                            },
                            value: '',
                        },
                    },
                    children: [
                        {
                            cells: {
                                'R§TPPA': {
                                    cssClass: 'strong-text top-right-indicator',
                                    isEditable: false,
                                    obj: {
                                        k: 'CFP0£02     ',
                                        p: '',
                                        t: 'OG',
                                    },
                                    value: 'CFP0£02     ',
                                },
                                NCOL: {
                                    isEditable: false,
                                    obj: {
                                        k: '4',
                                        p: '',
                                        t: 'NR',
                                    },
                                    value: '4',
                                },
                                'R§CDPA': {
                                    cssClass: 'strong-text top-right-indicator',
                                    isEditable: false,
                                    obj: {
                                        k: 'UO83           ',
                                        p: 'P0£02     ',
                                        t: 'CF',
                                    },
                                    value: 'UO83           ',
                                },
                                NFTE: {
                                    isEditable: false,
                                    obj: {
                                        k: '4.000',
                                        p: '',
                                        t: 'NR',
                                    },
                                    value: '4.00',
                                },
                            },
                            children: [],
                            disabled: false,
                            expandable: false,
                            icon: 'layers',
                            id: 'PO88',
                            isExpanded: false,
                            obj: {
                                k: 'PO88',
                                p: 'P0£03',
                                t: 'CF',
                            },
                            options: true,
                            style: {},
                            value: 'PO88: BSA Manager I Livello',
                        },
                    ],
                    disabled: false,
                    expandable: true,
                    icon: 'layers',
                    id: 'UO83',
                    isExpanded: true,
                    obj: {
                        k: 'UO83',
                        p: 'P0£02',
                        t: 'CF',
                    },
                    options: true,
                    style: {},
                    value: 'UO83: MAGNI ROBERTO - BSA Comitato Direzione',
                },
            ],
            disabled: false,
            expandable: true,
            icon: 'factory',
            id: '10',
            isExpanded: true,
            obj: {
                k: '10',
                p: 'AZI',
                t: 'CN',
            },
            options: true,
            style: {},
            value: '10: SMEUP BSA SRL',
        },
    ],
};

const dataStacked = {
    columns: [],
    rows: [
        {
            children: [
                {
                    children: [
                        {
                            children: [
                                {
                                    disabled: false,
                                    expandable: false,
                                    icon: 'favorite',
                                    id: 'LOCEXD',
                                    isExpanded: false,
                                    obj: {
                                        k: 'LOCEXD',
                                        p: 'B£AMO',
                                        t: 'TA',
                                    },
                                    options: true,
                                    style: {},
                                    value: 'Scheda oggetto',
                                    visible: true,
                                },
                            ],
                            disabled: false,
                            expandable: true,
                            icon: 'table-large',
                            id: 'FOS',
                            isExpanded: true,
                            obj: {
                                k: 'FOS',
                                p: 'BRE',
                                t: 'TA',
                            },
                            options: true,
                            style: {},
                            value: 'FOR Debiti operaz. societ.',
                            visible: true,
                        },
                        {
                            children: [
                                {
                                    disabled: false,
                                    expandable: false,
                                    icon: 'favorite',
                                    isExpanded: false,
                                    obj: {
                                        k: 'LOCEXD',
                                        p: 'B£AMO',
                                        t: 'TA',
                                    },
                                    options: true,
                                    style: {},
                                    value: 'Scheda oggetto',
                                    visible: true,
                                },
                                {
                                    children: [],
                                    disabled: false,
                                    expandable: false,
                                    icon: 'favorite',
                                    id: 'LOCTML',
                                    isExpanded: false,
                                    obj: {
                                        k: 'LOCTML',
                                        p: 'B£AMO',
                                        t: 'TA',
                                    },
                                    options: true,
                                    style: {},
                                    value: 'Timeline',
                                    visible: true,
                                },
                            ],
                            disabled: false,
                            expandable: true,
                            icon: 'table-large',
                            id: 'FOS',
                            isExpanded: true,
                            obj: {
                                k: 'FOS',
                                p: 'BRE',
                                t: 'TA',
                            },
                            options: true,
                            style: {},
                            value: 'FOR Debiti operaz. societ.',
                            visible: true,
                        },
                        {
                            children: [],
                            disabled: false,
                            expandable: false,
                            icon: 'table-large',
                            id: 'AGE',
                            isExpanded: false,
                            isWeird: true,
                            obj: {
                                k: 'AGE',
                                p: 'BRE',
                                t: 'TA',
                            },
                            options: true,
                            style: {},
                            value: 'Agente',
                            visible: true,
                        },
                        {
                            children: [
                                {
                                    children: [],
                                    disabled: false,
                                    expandable: false,
                                    icon: 'favorite',
                                    id: 'LOCTML',
                                    isExpanded: false,
                                    obj: {
                                        k: 'LOCTML',
                                        p: 'B£AMO',
                                        t: 'TA',
                                    },
                                    options: true,
                                    style: {},
                                    value: 'Timeline',
                                    visible: true,
                                },
                                {
                                    children: [],
                                    disabled: false,
                                    expandable: false,
                                    icon: 'favorite',
                                    isExpanded: false,
                                    obj: {
                                        k: 'LOCTML',
                                        p: 'B£AMO',
                                        t: 'TA',
                                    },
                                    options: true,
                                    style: {},
                                    value: 'Timeline',
                                    visible: true,
                                },
                            ],
                            disabled: false,
                            expandable: true,
                            icon: 'table-large',
                            id: 'BAN',
                            isExpanded: true,
                            obj: {
                                k: 'BAN',
                                p: 'BRE',
                                t: 'TA',
                            },
                            options: true,
                            style: {},
                            value: 'Banche',
                            visible: true,
                        },
                    ],
                    disabled: false,
                    expandable: true,
                    icon: 'table-large',
                    id: '03',
                    isExpanded: true,
                    obj: {
                        k: '03',
                        p: 'V§R',
                        t: 'TA',
                    },
                    options: true,
                    style: {},
                    value: 'Lombardia',
                    visible: true,
                },
                {
                    children: [],
                    disabled: false,
                    expandable: false,
                    icon: 'table-large',
                    id: '14',
                    isExpanded: false,
                    obj: {
                        k: '14',
                        p: 'V§R',
                        t: 'TA',
                    },
                    options: true,
                    style: {},
                    value: 'Molise',
                    visible: true,
                },
            ],
            disabled: false,
            expandable: true,
            icon: 'favorite',
            id: 'D0',
            isExpanded: true,
            obj: {
                k: 'D0',
                p: 'B£A',
                t: 'TA',
            },
            options: true,
            style: {},
            value: 'AcosUP Costi Avanzati',
            visible: true,
        },
    ],
};

const layout = {
    horizontal: true,
    sections: [
        {
            horizontal: false,
            sections: [
                {
                    content: [
                        {
                            column: '*TREECOL',
                        },
                    ],
                    horizontal: false,
                },
                {
                    content: [
                        {
                            column: 'NCOL',
                        },
                    ],
                    horizontal: false,
                },
                {
                    content: [
                        {
                            column: 'R§CDPA',
                        },
                    ],
                    horizontal: false,
                },
            ],
        },
    ],
};

const familyTreeLayout = document.getElementById('layout');
const familyTreeStaff = document.getElementById('staff');
const familyTreeStacked = document.getElementById('stacked');
familyTreeLayout.data = dataLayout;
familyTreeLayout.layout = layout;
familyTreeStaff.data = dataStaff;
familyTreeStaff.layout = 2;
familyTreeStacked.data = dataStacked;
familyTreeStacked.collapsible = false;
familyTreeStacked.stackedLeaves = true;

document.addEventListener('kup-familytree-click', (e) => {
    console.log(e);
});
document.addEventListener('kup-familytree-contextmenu', (e) => {
    console.log(e);
});
document.addEventListener('kup-familytree-dblclick', (e) => {
    console.log(e);
});
